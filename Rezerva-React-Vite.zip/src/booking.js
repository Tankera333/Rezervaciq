import { businesses, initialDate, localDate } from './config.js'

export function workingHours(business, date) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return null
  const day = new Date(date + 'T12:00:00')
  if (localDate(day) !== date) return null
  return business.hours[day.getDay()]
}

// Всеки ресурс има отделен масив за заетите места във всяка стъпка.
export function occupancy(business, date, rows, excludeId) {
  const hours = workingHours(business, date)
  const result = new Map()
  if (!hours) return result
  const count = (hours[1]-hours[0])/business.step
  for (const resource of business.resources) result.set(resource.id, new Int32Array(count+1))
  for (const row of rows) {
    if (row.id === excludeId) continue
    const slots = result.get(row.resource)
    const first = (row.start-hours[0])/business.step
    slots[first] += row.size
    slots[first+row.duration/business.step] -= row.size
  }
  for (const slots of result.values()) {
    for (let i=1; i<count; i++) slots[i] += slots[i-1]
  }
  return result
}

export function fits(business, hours, resource, loads, start, duration, size) {
  if (!hours || !resource || !loads || !business.durations.includes(duration) ||
      !Number.isInteger(size) || size < 1 || size > resource.capacity ||
      !Number.isInteger(start) || start < hours[0] || start+duration > hours[1] ||
      (start-hours[0]) % business.step !== 0) return false
  const first = (start-hours[0])/business.step
  for (let i=first; i<first+duration/business.step; i++) {
    if (loads[i]+size > resource.capacity) return false
  }
  return true
}

export const dayKey = (business, date) => business.id + '/' + date
// Началото трябва да е в бъдеща минута по местния часовник.
export function firstBookableMinute(date, now) {
  const today = localDate(now)
  if (date < today) return Infinity
  if (date > today) return 0
  return now.getHours()*60 + now.getMinutes() + 1
}

export function save(store, business, date, row, original, now = new Date()) {
  if (row.start < firstBookableMinute(date,now)) throw Error('Изберете бъдеща дата и час.')
  if (!row.name?.trim()) throw Error('Въведете име за резервацията.')
  const key = dayKey(business, date)
  const rows = store[key] ?? []
  if (original && !(store[original.key] ?? []).some(r => r.id === original.id)) throw Error('Записът липсва.')
  const resource = business.resources.find(r => r.id === row.resource)
  const index = occupancy(business, date, rows, original?.id)
  if (!fits(business, workingHours(business,date), resource, index.get(row.resource), row.start, row.duration, row.size))
    throw Error('Избраният интервал няма достатъчно свободни места или е извън работното време.')
  const next = { ...store }
  if (original) next[original.key] = store[original.key].filter(r => r.id !== original.id)
  next[key] = [...(next[key] ?? []), { ...row, name:row.name.trim() }].sort((a,b) => a.start-b.start)
  return next
}

const clinicNames = {a:'Николай Николов', b:'Георги Митрев'}

export function renameDemoPatients(store) {
  const next = {...store}
  for (const [key, rows] of Object.entries(store)) {
    if (!key.startsWith('clinic/')) continue
    next[key] = rows.map(row => /^clinic-[01](?:-\d{4}-\d{2}-\d{2})?$/.test(row.id)
      ? {...row, name:clinicNames[row.resource]} : row)
  }
  return next
}

export function seed(date = initialDate()) {
  const store = {}
  for (const b of businesses) {
    const hours = workingHours(b,date)
    if (!hours) continue
    store[dayKey(b,date)] = b.resources.map((r,i) => ({
      id:b.id+'-'+i, resource:r.id, name:b.id === 'clinic' ? clinicNames[r.id] : ['Алекс Димов','Мира Стоянова','Ива Колева'][i],
      start:hours[0]+(i+1)*60, duration:b.durations[1], size:Math.min(3,r.capacity)
    }))
  }
  return store
}

// Еднократно подготвя демонстрационната седмица, включително старите локални записи.
export function presentationWeek(previous) {
  const dates = Array.from({length:6}, (_,i) => '2026-11-' + (23+i))
  const next = {...previous}
  for (const b of businesses) {
    const templateDate = [initialDate(), '2026-11-24', ...dates].find(date => previous[dayKey(b,date)]?.length)
    const template = templateDate ? previous[dayKey(b,templateDate)] : seed(dates[0])[dayKey(b,dates[0])]
    for (const date of dates) {
      const key = dayKey(b,date)
      if (b.id === 'salon') {
        next[key] = ['Стеляна Демиркова','Севдалина Светославова'].map((name,i) => ({
          id:'salon-'+date+'-'+i, name, resource:b.resources[i].id,
          start:660+i*60, duration:60, size:1
        }))
      } else if (!(key in previous)) {
        const [open,close] = workingHours(b,date)
        next[key] = template.filter(r => r.start >= open && r.start+r.duration <= close)
          .map(r => ({...r,id:r.id+'-'+date}))
      }
    }
  }
  return next
}
