// Часовете са в минути след полунощ. Индекс 0 е неделя.
function week(start, end, saturdayEnd) {
  return [null, ...Array(5).fill([start, end]), [start, saturdayEnd]]
}
export const businesses = [
  { id: 'clinic', name: 'Медицински кабинет', icon: '✚', unit: 'Пациенти', step: 15,
    durations: [15, 30, 45], hours: week(540, 1020, 780),
    resources: [{id:'a', name:'Д-р Георгиев', capacity:1}, {id:'b', name:'Д-р Иванов', capacity:1}] },
  { id: 'salon', name: 'Салон за красота', icon: '✂', unit: 'Клиенти', step: 30,
    durations: [30, 60, 90], hours: week(600, 1140, 960),
    resources: [{id:'a', name:'Фризьорско място', capacity:1}, {id:'b', name:'Маникюр', capacity:1}, {id:'c', name:'Грим', capacity:1}] },
  { id: 'studio', name: 'Спортно студио', icon: '◈', unit: 'Участници', step: 30,
    durations: [30, 60, 90], hours: week(480, 1200, 960),
    resources: [{id:'a', name:'Зала за йога', capacity:12}, {id:'b', name:'Зала за пилатес', capacity:8}] }
]
export function localDate(date = new Date()) {
  return [date.getFullYear(), String(date.getMonth()+1).padStart(2,'0'), String(date.getDate()).padStart(2,'0')].join('-')
}
export function initialDate() {
  const day = new Date()
  if (day.getDay() === 0) day.setDate(day.getDate()+1)
  return localDate(day)
}
export const clock = m => String(Math.floor(m/60)).padStart(2,'0') + ':' + String(m%60).padStart(2,'0')
