import React, { memo, useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import { businesses, clock, initialDate, localDate } from './config.js'
import { dayKey, firstBookableMinute, fits, occupancy, save, presentationWeek, renameDemoPatients, workingHours } from './booking.js'
import './style.css'

const EMPTY = []
const STORAGE = 'rezerva.schedule.presentation.v3'
function load() {
  try {
    const current = localStorage.getItem(STORAGE)
    const previous = localStorage.getItem('rezerva.schedule.presentation.v2')
    const raw = current ?? previous ?? localStorage.getItem('rezerva.schedule.v1')
    if (!raw) return { data:presentationWeek({}) }
    const data = JSON.parse(raw)
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw Error()
    for (const [key,rows] of Object.entries(data)) {
      const [id,date] = key.split('/')
      const b = businesses.find(item => item.id === id)
      if (!b || !workingHours(b,date) || !Array.isArray(rows)) throw Error()
      const ids = new Set()
      const hours = workingHours(b,date)
      const emptySlots = new Int32Array((hours[1]-hours[0])/b.step)
      for (const r of rows) {
        if (typeof r.id !== 'string' || ids.has(r.id) || typeof r.name !== 'string' || !r.name.trim()) throw Error()
        ids.add(r.id)
        const resource = b.resources.find(item => item.id === r.resource)
        if (!fits(b,hours,resource,emptySlots,r.start,r.duration,r.size)) throw Error()
      }
    }
    return { data:current ? data : renameDemoPatients(previous ? data : presentationWeek(data)) }
  } catch { return { data:presentationWeek({}), warning:'Запазеният график е недостъпен. Заредени са примерни данни.' } }
}

function Field({label,children}) {
  return <label><span>{label}</span>{children}</label>
}
const ResourceSlots = memo(function ResourceSlots({item, times, onPick}) {
  return <article><div className="resource"><strong>{item.name}</strong><small>Капацитет · {item.capacity}</small></div>
    <div className="slots">{times.map(({t,reason,mark}) => {
      const content = clock(t)
      const label = [item.name,content,mark,reason].filter(Boolean).join(' · ')
      return reason
        ? <span key={t} className="blocked-slot" title={mark && mark !== 'Зает' ? mark+' · '+reason : reason}><button disabled aria-label={label}>{content}</button></span>
        : <button key={t} className={mark ? 'partial' : ''} title={mark || undefined} aria-label={label} onClick={() => onPick(item.id,t)}>{content}</button>
    })}</div></article>
})

function Editor({b, now, initial, original, data, onSave, onClose}) {
  const [form,setForm] = useState(initial)
  const [error,setError] = useState('')
  function change(key,value) { setForm({...form,[key]:value}); setError('') }
  const hours = workingHours(b,form.date)
  const starts = []
  const earliest = firstBookableMinute(form.date,now)
  if (hours) for (let t=hours[0];t+form.duration<=hours[1];t+=b.step) {
    if (t >= earliest) starts.push(t)
  }
  function submit(e) {
    e.preventDefault()
    try {
      const {date,...row} = form
      onSave(save(data,b,date,row,original),date,row.resource)
    } catch (err) { setError(err.message) }
  }
  return <dialog ref={node => { if(node && !node.open) node.showModal() }} onCancel={onClose} aria-labelledby="editor-title">
    <form onSubmit={submit}><header><h2 id="editor-title">{original?'Промяна':'Нова резервация'}</h2><button type="button" className="quiet" aria-label="Затвори" onClick={onClose}>✕</button></header>
    <Field label="Име на клиента"><input autoFocus required maxLength="80" value={form.name} onChange={e=>change('name',e.target.value)}/></Field>
    <Field label="Ресурс"><select value={form.resource} onChange={e=>change('resource',e.target.value)}>{b.resources.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}</select></Field>
    <div className="pair"><Field label="Дата"><input required type="date" min={localDate(now)} value={form.date} onChange={e=>change('date',e.target.value)}/></Field>
    <Field label="Продължителност"><select value={form.duration} onChange={e=>change('duration',+e.target.value)}>{b.durations.map(d=><option value={d} key={d}>{d} мин</option>)}</select></Field>
    <Field label="Начало"><select required value={starts.includes(form.start)?form.start:''} onChange={e=>change('start',+e.target.value)}><option value="">Изберете час</option>{starts.map(t=><option key={t} value={t}>{clock(t)}</option>)}</select></Field>
    <Field label={b.unit}><input type="number" min="1" required value={form.size || ''} onChange={e=>change('size',+e.target.value)}/></Field></div>
    {error && <p role="alert">{error}</p>}<button className="primary" disabled={!starts.length}>{hours?'Запази резервацията':'Неработен ден'}</button></form></dialog>
}

function Schedule({b,data,update}) {
  const [date,setDate] = useState(initialDate)
  const [now,setNow] = useState(() => new Date())
  useEffect(() => {
    let timer
    function refresh() {
      clearTimeout(timer)
      setNow(new Date())
      timer = setTimeout(refresh, 60000 - Date.now()%60000)
    }
    refresh()
    window.addEventListener('focus',refresh)
    return () => { clearTimeout(timer); window.removeEventListener('focus',refresh) }
  },[])
  const earliest = firstBookableMinute(date,now)
  const [resource,setResource] = useState('')
  const [duration,setDuration] = useState(b.durations[0])
  const [size,setSize] = useState(1)
  const [editor,setEditor] = useState(null)
  const [status,setStatus] = useState('')
  const key = dayKey(b,date)
  const rows = data[key] ?? EMPTY
  const hours = workingHours(b,date)
  const loads = useMemo(()=>occupancy(b,date,rows),[b,date,rows])
  const groups = useMemo(()=>b.resources.filter(r=>!resource || resource === r.id).map(item=>{
    const times = []
    const load = loads.get(item.id)
    if (hours) for (let t=hours[0];t<hours[1];t+=b.step) {
      const booked = load[(t-hours[0])/b.step]
      const mark = booked === item.capacity ? 'Зает' : booked ? (item.capacity-booked)+' свободни' : ''
      let reason = ''
      if (t < earliest) reason = 'Началният час е отминал'
      else if (booked === item.capacity) reason = 'Часът е зает'
      else if (t+duration > hours[1]) reason = 'Недостатъчно време до затваряне'
      else if (!Number.isInteger(size) || size < 1 || size > item.capacity) reason = 'Невалиден брой за този ресурс'
      else if (!fits(b,hours,item,load,t,duration,size)) reason = 'Няма достатъчно свободни места за целия интервал'
      times.push({t,reason,mark})
    }
    return {item,times}
  }),[b,resource,hours,duration,size,loads,earliest])
  const pick = React.useCallback((resource,start)=>setEditor({ initial:{ resource,start,date,duration,size,name:'',id:crypto.randomUUID() } }),[date,duration,size])
  return <main><div className="intro"><div><span className="eyebrow">{b.name}</span><h1>Дневен график</h1></div><div className="stamp">{hours?clock(hours[0])+' – '+clock(hours[1]):'Неработен ден'}</div></div>
    <div className="filters"><Field label="Дата"><input type="date" value={date} onChange={e=>{setDate(e.target.value);setStatus('')}}/></Field>
    <Field label="Ресурс"><select value={resource} onChange={e=>setResource(e.target.value)}><option value="">Всички ресурси</option>{b.resources.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}</select></Field>
    <Field label="Продължителност"><select value={duration} onChange={e=>setDuration(+e.target.value)}>{b.durations.map(d=><option key={d} value={d}>{d} мин</option>)}</select></Field>
    <Field label={b.unit}><input type="number" min="1" value={size || ''} onChange={e=>setSize(+e.target.value)}/></Field></div>
    <div className="columns"><section><header><h2>Свободни часове</h2><span className="counter">{groups.reduce((n,g)=>n+g.times.filter(slot=>!slot.reason).length,0)}</span></header>
    <p>Изберете начален час. Затъмнените часове са недостъпни.</p>{hours?groups.map(g=><ResourceSlots key={g.item.id} {...g} onPick={pick}/>):<p>{date?'Обектът е затворен на тази дата.':'Изберете дата.'}</p>}</section>
    <section><header><h2>Резервации за деня</h2><span className="counter">{rows.length}</span></header>
    {rows.length===0 && <p>Все още няма записвания за тази дата.</p>}
    {rows.map(r=><article key={r.id}><span className="time">{clock(r.start)} – {clock(r.start+r.duration)}</span><h3>{r.name}</h3><small>{b.resources.find(x=>x.id===r.resource).name} · {b.unit.toLowerCase()} {r.size}</small>
    <div className="actions"><button onClick={()=>setEditor({initial:{...r,date},original:{key,id:r.id}})}>Промени</button>
    <button className="cancel" onClick={()=>{if(window.confirm('Да се откаже ли резервацията на '+r.name+'?')){update({...data,[key]:rows.filter(x=>x.id!==r.id)});setStatus('Резервацията е отказана.')}}}>Откажи</button></div></article>)}</section></div>
    <p role="status">{status}</p>{editor && <Editor {...editor} now={now} data={data} b={b} onClose={()=>setEditor(null)} onSave={(next,day,savedResource)=>{update(next);setEditor(null);setDate(day);if(resource)setResource(savedResource);setStatus('Резервацията е запазена.')}}/>}</main>
}
function App() {
  const [b,setBusiness] = useState(businesses[0])
  const [initial] = useState(load)
  const [data,setData] = useState(initial.data)
  const [warning,setWarning] = useState(initial.warning)
  useEffect(()=>{try {localStorage.setItem(STORAGE,JSON.stringify(data))} catch {setWarning('Промените са налични само в тази сесия.')}},[data])
  return <><nav aria-label="Избор на бизнес"><strong className="brand"><i>▦</i> Резерва</strong><div>{businesses.map(x=><button key={x.id} aria-pressed={x===b} onClick={()=>setBusiness(x)}><b aria-hidden="true">{x.icon}</b>{x.name}</button>)}</div></nav>{warning && <p role="alert">{warning}</p>}<Schedule key={b.id} b={b} data={data} update={setData}/></>
}
createRoot(document.getElementById('root')).render(<App/>)
