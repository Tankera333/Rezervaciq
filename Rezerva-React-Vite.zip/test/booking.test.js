import test from 'node:test'
import assert from 'node:assert/strict'
import {businesses} from '../src/config.js'
import {save as saveAt, seed, fits, occupancy, workingHours, dayKey, presentationWeek} from '../src/booking.js'

const [clinic,,studio] = businesses
const save = (store,b,date,row,original) => saveAt(store,b,date,row,original,new Date(2026,10,23,8))
const day = '2026-11-24'
test('Демонстрационната седмица пази редактираните имена и включва двата часа в салона',()=>{
  const edited = [{id:'custom',name:'Ново име',resource:'a',start:600,duration:30,size:1}]
  const data = presentationWeek({['clinic/'+day]:edited})
  for (let d=23; d<=28; d++) {
    assert.deepEqual(data['salon/2026-11-'+d].map(r=>r.name),['Стеляна Демиркова','Севдалина Светославова'])
    assert.equal(data['clinic/2026-11-'+d][0].name,'Ново име')
  }
  assert.equal(data['clinic/'+day],edited)
})
const row = (id, start, size=1) => ({id,name:'Алекс',resource:'a',start,size,duration:30})
test('Краят на една резервация може да е начало на следващата',()=>{
  const data = save({},clinic,day,row('a',540))
  assert.doesNotThrow(()=>save(data,clinic,day,row('b',570)))
  assert.throws(()=>save(data,clinic,day,row('b',555)))
})
test('Проверява пиковата заетост и във втората половина на интервала',()=>{
  const data = save({},studio,day,row('a',510,8))
  assert.doesNotThrow(()=>save(data,studio,day,{...row('b',480,4),duration:60}))
  assert.throws(()=>save(data,studio,day,{...row('c',480,5),duration:60}))
})
test('Затворен ден, невалидна дата, стъпка, капацитет и край',()=>{
  assert.equal(workingHours(clinic,'2026-11-29'),null)
  assert.equal(workingHours(clinic,'2026-02-31'),null)
  for(const r of [row('x',541),row('x',1005),row('x',540,0),row('x',540,1.5),{...row('x',540),duration:17}])
    assert.throws(()=>save({},clinic,day,r))
})
test('Редакция на същия час и преместване в друг ден',()=>{
  const data=save({},clinic,day,row('x',540))
  const original={id:'x',key:dayKey(clinic,day)}
  const edited=save(data,clinic,day,{...row('x',540),name:'Мира'},original)
  assert.equal(edited[original.key][0].name,'Мира')
  const moved=save(edited,clinic,'2026-11-25',row('x',540),original)
  assert.equal(moved[original.key].length,0)
  assert.equal(moved[dayKey(clinic,'2026-11-25')].length,1)
})
test('Конфликт при промяна запазва оригинала',()=>{
  const data=save(save({},clinic,day,row('a',540)),clinic,day,row('b',570))
  const key=dayKey(clinic,day)
  assert.throws(()=>save(data,clinic,day,row('a',570),{id:'a',key}))
  assert.deepEqual(data[key].map(r=>r.start),[540,570])
})
test('Ресурсите и бизнесите имат независими графици',()=>{
  let data=save({},clinic,day,row('x',540))
  data=save(data,clinic,day,{...row('y',540),resource:'b'})
  data=save(data,studio,day,row('z',540))
  assert.equal(Object.keys(data).length,2)
})
test('Индексът съвпада с пряко преброяване за всеки възможен час',()=>{
  const data=seed(day)
  const rows=data[dayKey(studio,day)]
  const index=occupancy(studio,day,rows)
  const hours=workingHours(studio,day)
  for (const r of studio.resources) for (let t=hours[0];t<hours[1];t+=studio.step)
    for(const duration of studio.durations) for(const size of [1,4,8,12]){
      let ok=t+duration<=hours[1]
      for(let m=t;m<t+duration;m+=studio.step){
        const used=rows.filter(x=>x.resource===r.id && x.start<=m && m<x.start+x.duration).reduce((n,x)=>n+x.size,0)
        if(used+size>r.capacity) ok=false
      }
      assert.equal(fits(studio,hours,r,index.get(r.id),t,duration,size),ok)
    }
})

test('Блокира минала дата и започнал час при създаване и редакция',()=>{
  const now = new Date(2026,10,24,10,15,30)
  const reserve = (date,start) => saveAt({},clinic,date,row('a',start),undefined,now)
  for (const [date,start] of [['2026-11-23',990],[day,600],[day,615]]) {
    assert.throws(()=>reserve(date,start),/бъдеща дата и час/)
  }
  const data = reserve(day,630)
  assert.doesNotThrow(()=>reserve('2026-11-25',540))
  const key = dayKey(clinic,day)
  assert.throws(()=>saveAt(data,clinic,day,row('a',630),{id:'a',key},new Date(2026,10,24,10,31)),/бъдеща дата и час/)
  assert.equal(data[key][0].start,630)
})
